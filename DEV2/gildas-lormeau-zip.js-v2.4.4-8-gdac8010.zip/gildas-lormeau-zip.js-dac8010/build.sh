#!/bin/sh

npx rollup -c rollup-es5.config.js 
npx rollup -c